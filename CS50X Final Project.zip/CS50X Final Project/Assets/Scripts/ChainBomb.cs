using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChainBomb : MonoBehaviour
{
    public float bombFuseTime = 3f;
    public bool hit = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (LayerMask.NameToLayer("Bomb") == LayerMask.NameToLayer("Explosion")) {
            hit = true;;

            if (hit == true) {
                bombFuseTime = 0f;
            }
        }
    }
}